<?xml version="1.0" encoding="ASCII"?>
<emulation:BWTFile xmi:version="2.0" xmlns:xmi="http://www.omg.org/XMI" xmlns:emulation="http:///emulation.ecore">
  <CurrentLoadedTest href="platform:/resource/LIB_UTIL_CSF-implement.module/Tests/LIB_UTIL_CSF-implement.module2.bwt#/"/>
  <EmulationDataFile>ACED00057400224C49425F5554494C5F4353462D696D706C656D656E742E6D6F64756C65322E627774</EmulationDataFile>
</emulation:BWTFile>
