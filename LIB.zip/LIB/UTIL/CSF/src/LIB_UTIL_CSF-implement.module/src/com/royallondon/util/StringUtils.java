package com.royallondon.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;


public class StringUtils {

	public StringUtils() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		StringUtils x = new StringUtils();
//		String x1 = x.compress("richard was here");
//		String y1 = x.uncompress(x1);
//System.out.println(x.getFilterString("A,B,C,D(1,2,3),E,F(7,8,9),G,H"));
		System.out.println(new StringUtils().getStackOfCaller("tester.module.Process2/SubProcess->tester.module.SubProcess/SubProcess1->tester.module.SubProcess1"));
	}

	public String getStackOfCaller(String stack) {
		return getStackElement(stack, 1);
	}

	public String getStackElement(String stack, int depth) {
		String[] elements = stack.split("->");
		
		if (depth == 0)
			return elements[elements.length - 1];
		else {
			String item = elements[elements.length - depth - 1];
			if (depth < elements.length) {
				int pos = item.indexOf("/");
				if (pos >= 0)
					return item.substring(0, pos);
				else
					return item;
			}
			else
				return item;
		}
	}

	public String getFilterString(String filter) {
		StringBuilder reply = new StringBuilder(filter);
		
		boolean inSub = false;
		for (int pos = 0; pos < filter.length(); ++pos) {
			char testChar = reply.charAt(pos);
			if (testChar == '(') {
				inSub = true;
			}
			else if (testChar == ')') {
				inSub = false;
			}
			else if (inSub && (testChar == ',')) {
				reply.setCharAt(pos, '-');
			}
		}
		return reply.toString();
	}
	
	public String replaceRegEx(String str, String regex, String replacement) {
		return str.replaceAll(regex, replacement);
	}

	public String[] replaceRegExes(String str[], String regex[], String replacement[]) {
		assert str.length == regex.length;
		assert str.length == replacement.length;
		String response[] = new String[str.length];
		for (int i = 0; i < str.length; ++i) {
			response[i] = replaceRegEx(str[i], regex[i], replacement[i]);			
		}
		return response;
	}

	public String compress(String str) throws IOException {
		ByteArrayOutputStream rstBao = new ByteArrayOutputStream();
		GZIPOutputStream zos = new GZIPOutputStream(rstBao);
		zos.write(str.getBytes());
		zos.close();
		
		byte[] bytes = rstBao.toByteArray();
		rstBao.close();

		return Base64.getEncoder().encodeToString(bytes);
	}

	public String uncompress(String str) throws IOException {
		byte[] bytes = Base64.getDecoder().decode(str);
		ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
		GZIPInputStream gzin = new GZIPInputStream(bais);
	    ByteArrayOutputStream baos = new ByteArrayOutputStream();
	    byte[] buffer = new byte[8192];
        int len;
        while((len = gzin.read(buffer)) > 0)
        	baos.write(buffer, 0, len);
        baos.close();
        gzin.close();
        bais.close();

        return new String(baos.toByteArray(), "UTF-8");
    }
}
