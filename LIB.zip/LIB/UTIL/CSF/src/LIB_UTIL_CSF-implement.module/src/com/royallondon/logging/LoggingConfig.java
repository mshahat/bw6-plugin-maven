/**
 * 
 */
package com.royallondon.logging;

import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author richard
 *
 */
public class LoggingConfig {

	private static final String BASE_LOGGING_AUDIT = "csf.audit";
	private static final String BASE_LOGGING_TRACE = "csf.trace";
	private static final String BASE_LOGGING_LOG = "csf.log";

	// Create Concurrent HashMaps to persist the loggers so that level settings will persist
	private final static ConcurrentHashMap<String, Logger> _auditLoggers = new ConcurrentHashMap<String, Logger>();
	private final static ConcurrentHashMap<String, Logger> _traceLoggers = new ConcurrentHashMap<String, Logger>();
	private final static ConcurrentHashMap<String, Logger> _logLoggers = new ConcurrentHashMap<String, Logger>();
	
	private static final Level LOG_OFF = Level.FINE;
	private static final Level LOG_ON = Level.FINER;
	private static final Level LOG_PAYLOAD = Level.FINEST;

	public static final String LEVEL_OFF = "OFF";
	public static final String LEVEL_ON = "ON";
	public static final String LEVEL_PAYLOAD = "PAYLOAD";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoggingConfig.reset();

		LoggingConfig.setAuditLevel("", "PAYLOAD");
		System.out.println(LoggingConfig.isAuditEnabled("") == true);
		System.out.println(LoggingConfig.isAuditPayload("") == true);
		System.out.println(LoggingConfig.isAuditEnabled("fred") == true);
		System.out.println(LoggingConfig.isAuditPayload("fred") == true);

		LoggingConfig.setAuditLevel("", "ON");
		System.out.println(LoggingConfig.isAuditEnabled("") == true);
		System.out.println(LoggingConfig.isAuditPayload("") == false);
		System.out.println(LoggingConfig.isAuditEnabled("fred") == true);
		System.out.println(LoggingConfig.isAuditPayload("fred") == false);

		LoggingConfig.setAuditLevel("fred", "OFF");
		System.out.println(LoggingConfig.isAuditEnabled("") == true);
		System.out.println(LoggingConfig.isAuditPayload("") == false);
		System.out.println(LoggingConfig.isAuditEnabled("fred") == false);
		System.out.println(LoggingConfig.isAuditPayload("fred") == false);

	
		LoggingConfig.reset();
		System.out.println(LoggingConfig.isAuditEnabled("") == false);
		System.out.println(LoggingConfig.isAuditPayload("") == false);
		System.out.println(LoggingConfig.isAuditEnabled("fred") == false);
		System.out.println(LoggingConfig.isAuditPayload("fred") == false);

		LoggingConfig.setAuditLevel("fred", "PAYLOAD");
		System.out.println(LoggingConfig.isAuditEnabled("") == false);
		System.out.println(LoggingConfig.isAuditPayload("") == false);
		System.out.println(LoggingConfig.isAuditEnabled("fred") == true);
		System.out.println(LoggingConfig.isAuditPayload("fred") == true);
}

	public LoggingConfig() {
		super();
	}

	public static boolean isLogEnabled(String name) {
		return Logger.getLogger(logName(name)).isLoggable(LOG_ON);
	}

	public static boolean isLogPayload(String name) {
		return Logger.getLogger(logName(name)).isLoggable(LOG_PAYLOAD);
	}

	public static void setLogLevel(String name, String level) {
		setLogLevel(name, levelFromString(level));
	}

	public static void setLogLevel(String name, Level level) {
		String context = logName(name);
		Logger logger = Logger.getLogger(context);
		logger.setLevel(level);

		// Persist the logger so that the setting remains after garbage collection
		synchronized (_logLoggers) {
			_logLoggers.put(context, logger);
		}
	}

	public static boolean isTraceEnabled(String name) {
		return Logger.getLogger(traceName(name)).isLoggable(LOG_ON);
	}

	public static boolean isTracePayload(String name) {
		return Logger.getLogger(traceName(name)).isLoggable(LOG_PAYLOAD);
	}

	public static void setTraceLevel(String name, String level) {
		setTraceLevel(name, levelFromString(level));
	}

	public static void setTraceLevel(String name, Level level) {
		String context = traceName(name);
		Logger logger = Logger.getLogger(context);
		logger.setLevel(level);

		// Persist the logger so that the setting remains after garbage collection
		synchronized (_traceLoggers) {
			_traceLoggers.put(context, logger);
		}
	}

	public static boolean isAuditEnabled(String name) {
		return Logger.getLogger(auditName(name)).isLoggable(LOG_ON);
	}

	public static boolean isAuditPayload(String name) {
		return Logger.getLogger(auditName(name)).isLoggable(LOG_PAYLOAD);
	}

	public static void setAuditLevel(String name, String level) {
		setAuditLevel(name, levelFromString(level));
	}

	public static void setAuditLevel(String name, Level level) {
		String context = auditName(name);
		Logger logger = Logger.getLogger(context);
		logger.setLevel(level);

		// Persist the logger so that the setting remains after garbage collection
		synchronized (_auditLoggers) {
			_auditLoggers.put(context, logger);
		}
	}

	public static void reset() {
		// Reset audit loggers to use parent level and remove strong references
		for (Entry<String, Logger> logger : _auditLoggers.entrySet()) {
			logger.getValue().setLevel(null);
		}
		_auditLoggers.clear();
		
		// Reset log loggers to use parent level and remove strong references
		for (Entry<String, Logger> logger : _logLoggers.entrySet()) {
			logger.getValue().setLevel(null);
		}
		_logLoggers.clear();
		
		// Reset trace loggers to use parent level and remove strong references
		for (Entry<String, Logger> logger : _traceLoggers.entrySet()) {
			logger.getValue().setLevel(null);
		}
		_traceLoggers.clear();
	}

	public static void config() {
//		_rootLogLevel = Logger.getLogger(BASE_LOGGING_LEVEL);
//		_rootLogPayload = Logger.getLogger(BASE_LOGGING_PAYLOAD);
//
//		try {
//			for (Handler handler : _rootLogLevel.getHandlers()) {
//				_rootLogLevel.removeHandler(handler);
//			}
//
//			for (Handler handler : _rootLogPayload.getHandlers()) {
//				_rootLogPayload.removeHandler(handler);
//			}
//		} catch (SecurityException ex) {
//		}
	}

//	private static Level levelFromInt(int level)
//	{
//		switch (level) {
//			case 0:
//				return LOG_OFF;
//			case 1:
//				return LOG_ON;
//			case 2:
//				return LOG_PAYLOAD;
//			default:
//				return LOG_OFF;
//		}
//	}

	private static Level levelFromString(String level)
	{
		if (LEVEL_PAYLOAD.equals(level))
			return LOG_PAYLOAD;
		else if (LEVEL_ON.equals(level))
			return LOG_ON;
		else
			return LOG_OFF;
	}

	private static String logName(String context)
	{
		return contextFromString(BASE_LOGGING_LOG, context);
	}

	private static String traceName(String context)
	{
		return contextFromString(BASE_LOGGING_TRACE, context);
	}

	private static String auditName(String context)
	{
		return contextFromString(BASE_LOGGING_AUDIT, context);
	}
	
	private static String contextFromString(String base, String context)
	{
		if ("".equals(context))
			return base;
		else
			return base + "." + context;
	}
}
