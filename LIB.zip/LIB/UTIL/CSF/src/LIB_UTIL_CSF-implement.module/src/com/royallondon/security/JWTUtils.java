package com.royallondon.security;

import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;

import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.spec.RSAPublicKeySpec;
import java.util.Base64;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.MissingClaimException;

import java.util.Map.Entry;


public class JWTUtils {

	public static void main(String[] args) throws Exception {
		
		JWTUtils.setRSAPublicKey("qnTksBdxOiOlsmRNd-mMS2M3o1IDpK4uAr0T4_YqO3zYHAGAWTwsq4ms-NWynqY5HaB4EThNxuq2GWC5JKpO1YirOrwS97B5x9LJyHXPsdJcSikEI9BxOkl6WLQ0UzPxHdYTLpR4_O-0ILAlXw8NU4-jB4AP8Sn9YGYJ5w0fLw5YmWioXeWvocz1wHrZdJPxS8XnqHXwMUozVzQj-x6daOv5FmrHU1r9_bbp0a1GLv4BbTtSh4kMyz1hXylho0EvPg5p9YIKStbNAW9eNWvv5R8HN7PPei21AsUqxekK0oW9jnEdHewckToX7x5zULWKwwZIksll0XnVczVgy7fCFw", "AQAB", 100000000);
//		JWTUtils.setRSAPublicKey("MIIDBTCCAfGgAwIBAgIQNQb+T2ncIrNA6cKvUA1GWTAJBgUrDgMCHQUAMBIxEDAOBgNVBAMTB0RldlJvb3QwHhcNMTAwMTIwMjIwMDAwWhcNMjAwMTIwMjIwMDAwWjAVMRMwEQYDVQQDEwppZHNydjN0ZXN0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqnTksBdxOiOlsmRNd+mMS2M3o1IDpK4uAr0T4/YqO3zYHAGAWTwsq4ms+NWynqY5HaB4EThNxuq2GWC5JKpO1YirOrwS97B5x9LJyHXPsdJcSikEI9BxOkl6WLQ0UzPxHdYTLpR4/O+0ILAlXw8NU4+jB4AP8Sn9YGYJ5w0fLw5YmWioXeWvocz1wHrZdJPxS8XnqHXwMUozVzQj+x6daOv5FmrHU1r9/bbp0a1GLv4BbTtSh4kMyz1hXylho0EvPg5p9YIKStbNAW9eNWvv5R8HN7PPei21AsUqxekK0oW9jnEdHewckToX7x5zULWKwwZIksll0XnVczVgy7fCFwIDAQABo1wwWjATBgNVHSUEDDAKBggrBgEFBQcDATBDBgNVHQEEPDA6gBDSFgDaV+Q2d2191r6A38tBoRQwEjEQMA4GA1UEAxMHRGV2Um9vdIIQLFk7exPNg41NRNaeNu0I9jAJBgUrDgMCHQUAA4IBAQBUnMSZxY5xosMEW6Mz4WEAjNoNv2QvqNmk23RMZGMgr516ROeWS5D3RlTNyU8FkstNCC4maDM3E0Bi4bbzW3AwrpbluqtcyMN3Pivqdxx+zKWKiORJqqLIvN8CT1fVPxxXb/e9GOdaR8eXSmB0PgNUhM4IjgNkwBbvWC9F/lzvwjlQgciR7d4GfXPYsE1vf8tmdQaY8/PtdAkExmbrb9MihdggSoGXlELrPA91Yce+fiRcKY3rQlNWVd4DOoJ/cPXsXwry8pWjNCo5JD8Q+RQ5yZEy7YPoifwemLhTdsBz3hlZr28oCGJ3kbnpW0xGvQb3VHSTVVbeei0CfXoW6iz1", 100000000);
		String[] x = JWTUtils.validateJWT("1eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6ImEzck1VZ01Gdjl0UGNsTGE2eUYzekFrZnF1RSIsImtpZCI6ImEzck1VZ01Gdjl0UGNsTGE2eUYzekFrZnF1RSJ9.eyJpc3MiOiJodHRwOi8vdndlaDd0YmFyYzAwNTo0NDMzMy9jb3JlIiwiYXVkIjoiaHR0cDovL3Z3ZWg3dGJhcmMwMDU6NDQzMzMvY29yZS9yZXNvdXJjZXMiLCJleHAiOjE1MDY2ODAxNDEsIm5iZiI6MTUwNjY3NjU0MSwiY2xpZW50X2lkIjoianMudXNlcm1hbmFnZXIiLCJzY29wZSI6WyJyZWFkIiwid3JpdGUiXSwic3ViIjoiODg0MjExMTMiLCJhdXRoX3RpbWUiOjE1MDY2NzY1NDEsImlkcCI6Imlkc3J2IiwiYW1yIjpbInBhc3N3b3JkIl19.BOHaFR3tobE3fA6tuj7kbLLr89-8rpVO7cXaYuYxecpDEScAc1d7z1syqWc2iq7nBgd30y7QVb2B7qoG1C5iIQL8VFUXxosX-00q_ZJlOV2xtQ7Y8EWwdYJYOlGOxTSIVifeDfD9XMKI8BxVZs9shJr6PZ9P7d8nD9GeYObntmjmM1UjPWH-Of5O5VW7FUHSLcx3VhUoejvo9AJ34zdo82SfpgZb_NRzXZWsys6ssmWZ7ajbRteExsh1wrOXZKhgM3EgjxuNdi8UtHp8oLJqRlklXRPoRZta7kkTrt7ftjx7Ky3scIzrJ0oS6dV24sb8uN2ZGJ4D5U14sxrBzkI6bA");
		for (String y : x) {
			System.out.println(y);
		}
		System.exit(0);
	}
	
	private static JwtParser _jwtParser;
	
	public JWTUtils() {
		super();
	}

	public static synchronized String setRSAPublicKey(String modStr, String expStr, long clockSkewSeconds) {
		try {
			BigInteger modulus = new BigInteger(1, Base64.getUrlDecoder().decode(modStr));
			BigInteger exponent = new BigInteger(1, Base64.getUrlDecoder().decode(expStr));
			
			Key publicKey = KeyFactory.getInstance("RSA").generatePublic(new RSAPublicKeySpec(modulus, exponent));
			_jwtParser = Jwts.parser().setAllowedClockSkewSeconds(clockSkewSeconds).setSigningKey(publicKey);
		
			return "";
		}
		catch (Exception ex) {
			_jwtParser = null;
			return ex.getMessage();
		}
	}

	
	public static boolean isRSAPublicKeyInitialised() {
		return _jwtParser != null;
	}

	
	public static String[] validateJWT(String jwtString) {

		if (!isRSAPublicKeyInitialised()) {
			return new String[] { "RSA key is not initialised" };
		}
			
		try {
			Jws<Claims> jws = _jwtParser.parseClaimsJws(jwtString);
			Claims claims = jws.getBody();
			if (claims.getNotBefore() == null) {
				throw new MissingClaimException(jws.getHeader(), claims, "No nbf claim");	
			}
			else if (claims.getExpiration() == null) {
				throw new MissingClaimException(jws.getHeader(), claims, "No exp claim");	
			}
			else if (claims.getExpiration() == null) {
				throw new MissingClaimException(jws.getHeader(), claims, "No subject claim");	
			}
	
			String claimValues[] = new String[claims.size()];
			int index = 0;
			for (Entry<String,Object> claim : claims.entrySet()) {
				claimValues[index++] = claim.getKey() + "=" + claim.getValue().toString();
			}
		
			return claimValues;
		}
		catch (Exception ex) {

			String input = ex.getMessage();
			byte[] ascii = new byte[input.length()];
			for (int i = 0; i < input.length(); i++) {
			    char ch = input.charAt(i);
			    ascii[i] = (ch >= 0x20) && (ch <= 0x7F) ? (byte) ch : (byte) '?';
			}
					
			return new String[] { new String(ascii) };
		}
	}
}
