package com.royallondon.logging;

import java.util.Vector;

public class SystemLogSharedCache {
public static Vector<String> m_cache ; 

private String[] m_empty_string_array = new String[0];

	
	public SystemLogSharedCache() {
		super();
		
	}
	
	public boolean put(String p_logevent_xml, int p_m_size) {
	
		if(m_cache == null)
			m_cache = new Vector<String>(p_m_size);
		if(m_cache.size()>= p_m_size)
			return false;
		m_cache.add(p_logevent_xml);
		return true;
	}
	
	
	public String remove() {
		return (m_cache != null && m_cache.size()>0)? m_cache.remove(0) : null;
	}
	
	public synchronized String[] removeAll() {
		if(m_cache == null)
			return null;

		String[] p_logevent_xml_list = (m_cache.size()>0)? m_cache.toArray(m_empty_string_array) : null;
		m_cache.removeAllElements();
		return p_logevent_xml_list;
	}
	
	public synchronized String[] removeSubset(int p_subset_size) {
		
		if(m_cache == null)
			return null;

		int p_local_subset_size = m_cache.size() >= p_subset_size ? p_subset_size
				: m_cache.size();
		if (p_local_subset_size > 0) {
			String[] local_m_cache = m_cache.subList(0, p_local_subset_size).toArray(m_empty_string_array);
			m_cache.subList(0, p_local_subset_size).clear();
			return local_m_cache;
		} else
			//When subset size <= to 0 removeAll()
			return this.removeAll();
	}

}
